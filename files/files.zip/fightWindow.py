import tkinter
import tkinter.ttk

from PIL import ImageTk, Image

import classes


def fight_settings(check_tab_exists_by_label, notebook: tkinter.ttk.Notebook, fontD: tkinter.font.Font):
    def fighting():
        global first_result_window, second_player, first_player, imagef1, imagef2, imagef1Attack, imagef2Attack, imagef1Damage, imagef2Damage
        turn = True

        match cmb_of_player1.get():
            case "Воин":
                first_player = classes.Warrior()
                imagef1 = ImageTk.PhotoImage(Image.open('images_hero0.2/Обычный воин.афк.png'))
                imagef1Attack = ImageTk.PhotoImage(Image.open('images_hero0.2/Обычный воин.атака.png'))
                imagef1Damage = ImageTk.PhotoImage(Image.open('images_hero0.2/Обычный воин.урон.png'))
            case 'Рыцарь':
                first_player = classes.Knight()
                imagef1 = ImageTk.PhotoImage(Image.open('images_hero0.2/Рыцарь.афк.png'))
                imagef1Attack = ImageTk.PhotoImage(Image.open('images_hero0.2/Рыцарь.атака.png'))
                imagef1Damage = ImageTk.PhotoImage(Image.open('images_hero0.2/Рыцарь.урон.png'))
            case "Защитник":
                first_player = classes.Defender()
                imagef1 = ImageTk.PhotoImage(Image.open('images_hero0.2/Защитник.афк.png'))
                imagef1Attack = ImageTk.PhotoImage(Image.open('images_hero0.2/Защитник.атака.png'))
                imagef1Damage = ImageTk.PhotoImage(Image.open('images_hero0.2/Защитник.урон.png'))
            case "Вампир":
                first_player = classes.Vampire()
                imagef1 = ImageTk.PhotoImage(Image.open('images_hero0.2/Вампир.афк.png'))
                imagef1Attack = ImageTk.PhotoImage(Image.open('images_hero0.2/Вампир.атака.png'))
                imagef1Damage = ImageTk.PhotoImage(Image.open('images_hero0.2/Вампир.урон.png'))
            case "Копейщик":
                first_player = classes.Lancer()
                imagef1 = ImageTk.PhotoImage(Image.open('images_hero0.2/Копьеносец.афк.png'))
                imagef1Attack = ImageTk.PhotoImage(Image.open('images_hero0.2/Копьеносец.атака.png'))
                imagef1Damage = ImageTk.PhotoImage(Image.open('images_hero0.2/Копьеносец.урон.png'))
        match cmb_of_player2.get():
            case "Воин":
                second_player = classes.Warrior()
                imag2 = Image.open('images_hero0.2/Обычный воин.афк.png')
                imagef2 = imag2.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2 = ImageTk.PhotoImage(imagef2)
                img2Attack = Image.open('images_hero0.2/Обычный воин.атака.png')
                imagef2Attack = img2Attack.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2Attack = ImageTk.PhotoImage(imagef2Attack)
                img2Damage = Image.open('images_hero0.2/Обычный воин.урон.png')
                imagef2Damage = img2Damage.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2Damage = ImageTk.PhotoImage(imagef2Damage)
            case 'Рыцарь':
                second_player = classes.Knight()
                imag2 = Image.open('images_hero0.2/Рыцарь.афк.png')
                imagef2 = imag2.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2 = ImageTk.PhotoImage(imagef2)
                img2Attack = Image.open('images_hero0.2/Рыцарь.атака.png')
                imagef2Attack = img2Attack.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2Attack = ImageTk.PhotoImage(imagef2Attack)
                img2Damage = Image.open('images_hero0.2/Рыцарь.урон.png')
                imagef2Damage = img2Damage.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2Damage = ImageTk.PhotoImage(imagef2Damage)
            case "Защитник":
                second_player = classes.Defender()
                imag2 = Image.open('images_hero0.2/Защитник.афк.png')
                imagef2 = imag2.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2 = ImageTk.PhotoImage(imagef2)
                img2Attack = Image.open('images_hero0.2/Защитник.атака.png')
                imagef2Attack = img2Attack.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2Attack = ImageTk.PhotoImage(imagef2Attack)
                img2Damage = Image.open('images_hero0.2/Защитник.урон.png')
                imagef2Damage = img2Damage.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2Damage = ImageTk.PhotoImage(imagef2Damage)
            case "Вампир":
                second_player = classes.Vampire()
                imag2 = Image.open('images_hero0.2/Вампир.афк.png')
                imagef2 = imag2.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2 = ImageTk.PhotoImage(imagef2)
                img2Attack = Image.open('images_hero0.2/Вампир.атака.png')
                imagef2Attack = img2Attack.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2Attack = ImageTk.PhotoImage(imagef2Attack)
                img2Damage = Image.open('images_hero0.2/Вампир.урон.png')
                imagef2Damage = img2Damage.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2Damage = ImageTk.PhotoImage(imagef2Damage)
            case "Копейщик":
                second_player = classes.Lancer()
                imag2 = Image.open('images_hero0.2/Копьеносец.афк.png')
                imagef2 = imag2.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2 = ImageTk.PhotoImage(imagef2)
                img2Attack = Image.open('images_hero0.2/Копьеносец.атака.png')
                imagef2Attack = img2Attack.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2Attack = ImageTk.PhotoImage(imagef2Attack)
                img2Damage = Image.open('images_hero0.2/Копьеносец.урон.png')
                imagef2Damage = img2Damage.transpose(Image.FLIP_LEFT_RIGHT)
                imagef2Damage = ImageTk.PhotoImage(imagef2Damage)

        def fight(fighter1: classes.Warrior, fighter2: classes.Warrior):
            nonlocal turn
            if fighter2.is_alive and fighter1.is_alive:
                if turn:
                    if fighter1.is_alive:
                        if isinstance(fighter1, classes.Vampire):
                            fighter2.takingDamage(fighter1.attack)
                            p1_image.configure(image=imagef1Attack)
                            p2_image.configure(image=imagef2Damage)
                            btnFight.config(state='disabled')
                            p1_image.after(1000, lambda: (
                                p1_image.configure(image=imagef1), p2_image.configure(image=imagef2), btnFight.config(state='normal')))

                            if isinstance(fighter2, classes.Defender):
                                if fighter1.health < classes.Vampire.health:
                                    fighter1.health += (fighter1.attack - fighter2.defence) * fighter1.vamperism
                            else:
                                if fighter1.health < classes.Vampire.health:
                                    fighter1.health += fighter1.attack * fighter1.vamperism
                        else:
                            fighter2.takingDamage(fighter1.attack)
                            p1_image.configure(image=imagef1Attack)
                            p2_image.configure(image=imagef2Damage)
                            btnFight.config(state='disabled')
                            p1_image.after(1000, lambda: (
                                p1_image.configure(image=imagef1), p2_image.configure(image=imagef2), btnFight.config(state='normal')))

                else:
                    if fighter2.is_alive:
                        if isinstance(fighter2, classes.Vampire):
                            fighter1.takingDamage(fighter2.attack)
                            p1_image.configure(image=imagef1Damage)
                            p2_image.configure(image=imagef2Attack)
                            btnFight.config(state='disabled')
                            p1_image.after(1000, lambda: (
                                p1_image.configure(image=imagef1), p2_image.configure(image=imagef2), btnFight.config(state='normal')))

                            if isinstance(fighter1, classes.Defender):
                                if fighter2.health < classes.Vampire.health:
                                    fighter2.health += (fighter2.attack - fighter1.defence) * fighter2.vamperism
                            else:
                                if fighter2.health < classes.Vampire.health:
                                    fighter2.health += fighter2.attack * fighter2.vamperism
                        else:
                            fighter1.takingDamage(fighter2.attack)
                            p1_image.configure(image=imagef1Damage)
                            p2_image.configure(image=imagef2Attack)
                            btnFight.config(state='disabled')
                            p1_image.after(1000, lambda: (
                                p1_image.configure(image=imagef1), p2_image.configure(image=imagef2), btnFight.config(state='normal')))

                turn = not turn
                health1.configure(text=fighter1.health)
                health2.configure(text=fighter2.health)
                if not fighter2.is_alive or not fighter1.is_alive:
                    results_of_fight()
                    if fighter2.is_alive:
                        res.configure(text='Второй боец победил')
                    elif fighter1.is_alive:
                        res.configure(text='Первый боец победил')
            else:
                results_of_fight()
                if fighter2.is_alive:
                    res.configure(text='Второй боец победил')
                elif fighter1.is_alive:
                    res.configure(text='Первый боец победил')

        def frameCreate():
            global first_result_window, health1, health2, attack1, attack2, p1_image, p2_image, btnFight, heartImage, swordImage, defenceImage, vampirismImage
            first_result_window = tkinter.ttk.Frame(notebook)
            notebook.add(first_result_window, text='Результаты дуэли')
            notebook.select(first_result_window)

            heartImage = ImageTk.PhotoImage(Image.open('images/heart.png'))
            swordImage = ImageTk.PhotoImage(Image.open('images/sword.png'))
            defenceImage = ImageTk.PhotoImage(Image.open('images/defense.png'))
            vampirismImage = ImageTk.PhotoImage(Image.open('images/vampirism.png'))

            f1Frame = tkinter.ttk.Frame(first_result_window)
            f2Frame = tkinter.ttk.Frame(first_result_window)
            f1Frame.pack(anchor='n', side='left')
            f2Frame.pack(anchor='n', side='right')
            health1 = tkinter.Label(f1Frame, text=first_player.health, image=heartImage, compound='left')
            attack1 = tkinter.Label(f1Frame, text=first_player.attack, image=swordImage, compound='left')
            health2 = tkinter.Label(f2Frame, text=second_player.health, image=heartImage, compound='left')
            attack2 = tkinter.Label(f2Frame, text=second_player.attack, image=swordImage, compound='left')

            p1_image = tkinter.Label(first_result_window, image=imagef1)
            p2_image = tkinter.Label(first_result_window, image=imagef2)
            p1_image.pack(side='left')
            p2_image.pack(side='right')
            health1.pack(side='left')
            health2.pack(side='right')
            attack1.pack(side='left')
            attack2.pack(side='right')

            if hasattr(first_player, 'defence'):
                defence1 = tkinter.Label(f1Frame, text=first_player.defence, image=defenceImage, compound='left')
                defence1.pack(side='left')
            if hasattr(first_player, 'vamperism'):
                vampirism1 = tkinter.Label(f1Frame, text=first_player.vamperism, image=vampirismImage, compound='left')
                vampirism1.pack(side='left')
            if hasattr(second_player, 'defence'):
                defence2 = tkinter.Label(f2Frame, text=second_player.defence, image=defenceImage, compound='left')
                defence2.pack(side='right')
            if hasattr(second_player, 'vamperism'):
                vampirism2 = tkinter.Label(f2Frame, text=second_player.vamperism, image=vampirismImage, compound='left')
                vampirism2.pack(side='right')
            btnFight = tkinter.Button(first_result_window, text='Ход',
                                      command=lambda: fight(first_player, second_player), font=fontD)
            btnFight.pack(anchor='center', side='bottom')
        if not check_tab_exists_by_label('Результаты дуэли'):
            frameCreate()
        else:
            first_result_window.destroy()
            frameCreate()

    def results_of_fight():
        global res
        if not check_tab_exists_by_label('Результат дуэли'):
            first_result_window.destroy()
            result = tkinter.ttk.Frame(notebook)
            notebook.add(result, text='Результат дуэли')
            notebook.select(result)
            res = tkinter.Label(result)
            res.pack()
            result.after(3000, lambda: result.destroy())

    if not check_tab_exists_by_label('Выбор дуэлянтов'):
        fight_window = tkinter.ttk.Frame(notebook)
        notebook.add(fight_window, text='Выбор дуэлянтов')
        notebook.select(fight_window)
        cmb_of_player1 = tkinter.ttk.Combobox(fight_window, width=20, state='readonly', font=fontD)
        cmb_of_player1['values'] = ['Рыцарь', 'Воин', 'Защитник', 'Вампир', 'Копейщик']
        cmb_of_player1.pack(pady=10)
        cmb_of_player1.set(value='Воин')

        cmb_of_player2 = tkinter.ttk.Combobox(fight_window, width=20, state='readonly', font=fontD)
        cmb_of_player2['values'] = ['Рыцарь', 'Воин', 'Защитник', 'Вампир', 'Копейщик']
        cmb_of_player2.pack(pady=10)
        cmb_of_player2.set(value='Воин')

        fighting_btn = tkinter.Button(fight_window, text='Старт', command=fighting, font=fontD)
        fighting_btn.pack(pady=10)
