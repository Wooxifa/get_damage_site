import tkinter
import tkinter.font
import tkinter.ttk
from tkinter.filedialog import askopenfilename
from webbrowser import open_new
from PIL import ImageTk, Image
from pygame import mixer
from battleWindow import battle_settings
from fightWindow import fight_settings
from classes import *

import pyglet

pyglet.font.add_file('EpilepsySans.ttf')


class Created:
    created: bool

    def __init__(self):
        self.created = False

    def switch(self):
        self.created = not self.created


class Notebook(tkinter.ttk.Notebook):
    def __init__(self):
        super().__init__()

    def advancedForget(self):
        if self.index(self.select()) != 0:
            self.forget(self.select())


def chooseMode():
    if not check_tab_exists_by_label('Выбор режима'):
        first_window = tkinter.ttk.Frame(notebook)
        notebook.add(first_window, text='Выбор режима')
        notebook.select(first_window)
        lbl = tkinter.Label(first_window, text='Выберите режим', font=fontD, justify='center',
                            anchor='center')
        lbl.pack()

        btn_of_fight = tkinter.Button(first_window, text='Дуэль', bg='aqua', fg='black',
                                      command=lambda: fight_settings(check_tab_exists_by_label, notebook, fontD),
                                      font=fontD)
        btn_of_fight.pack(pady=10)

        btn_of_battle = tkinter.Button(first_window, text='Сражение армий', bg='aqua', fg='black',
                                       command=lambda: battle_settings(check_tab_exists_by_label, notebook, fontD),
                                       font=fontD)
        btn_of_battle.pack(pady=10)


def playMusic():
    mixer.music.load(music_name)
    global play
    play = not play
    if play:
        mixer.music.play(-1)
        btnMusic.configure(image=music_crossed)
    else:
        mixer.music.stop()
        btnMusic.configure(image=music)


def keyboardDetection(event):
    if event.keysym == 'Tab':
        global music_name
        music_name = askopenfilename()
        if music_name == '':
            music_name = '48bb90af8e1e401.mp3'
    if event.keycode == 77:
        playMusic()
    if event.keycode == 27:
        notebook.advancedForget()
    if event.keycode == 73:
        Info()
    if event.keycode == 83:
        chooseMode()


def Info():
    if not createdWinInfo.created:
        winInfo = tkinter.Toplevel(window, background='grey70')
        winInfo.focus_set()
        winInfo.bind('<KeyPress>', lambda e: (winInfo.destroy(), createdWinInfo.switch()) if e.keycode == 27 else None)
        window.geometry(
            f"+{(window.winfo_screenwidth() // 2) - (1200 // 2)}+{(window.winfo_screenheight() // 2) - (700 // 2)}")
        Link = tkinter.Label(winInfo, text='Сайт об игре', fg='blue', cursor='hand2', background='grey70', font=fontD)
        Link.pack()
        Link.bind('<Button-1>', lambda e: open_new('https://tabzzires.github.io'))
        Link.bind('<Enter>', lambda e: Link.configure(font=('Epilepsy Sans', 60, 'underline')))
        Link.bind('<Leave>', lambda e: Link.configure(font=fontD))
        infoBtn = tkinter.Label(winInfo, font=fontD, background='grey70',
                                text='M/Ь - музыка\nTab - Выбрать музыку\n Esc - закрыть текущую вкладку\n I/Ш - информация\n\n Окна создания армий\n E/У - создать армии\n\nОкно информации\nEsc - закрыть окно')
        infoBtn.pack()
        createdWinInfo.switch()
        winInfo.protocol('WM_DELETE_WINDOW', lambda: (createdWinInfo.switch(), winInfo.destroy()))


def ClassesData():
    if not createdWinClasses.created:
        winClasses = tkinter.Toplevel(window, background='grey70')
        winClasses.focus_set()
        createdWinClasses.switch()
        Title = tkinter.Label(winClasses, background='grey70',
                              text='В этом окне вы сможете посмотреть характеристики каждого класса', wraplength=1900)
        Title.pack()

        classesnotebook = tkinter.ttk.Notebook(winClasses)
        warriorTab = tkinter.ttk.Frame(classesnotebook)
        knightTab = tkinter.ttk.Frame(classesnotebook)
        defenderTab = tkinter.ttk.Frame(classesnotebook)
        vampireTab = tkinter.ttk.Frame(classesnotebook)
        lancerTab = tkinter.ttk.Frame(classesnotebook)

        classesnotebook.add(warriorTab, text='Воин', sticky='w')
        classesnotebook.add(knightTab, text='Рыцарь', sticky='w')
        classesnotebook.add(defenderTab, text='Защитник', sticky='w')
        classesnotebook.add(vampireTab, text='Вампир', sticky='w')
        classesnotebook.add(lancerTab, text='Копейщик', sticky='w')

        l1 = tkinter.Label(warriorTab, text=f'Здоровье: {Warrior.health}  Атака: {Warrior.attack}')
        l1.pack()
        l2 = tkinter.Label(knightTab, text=f'Здоровье: {Knight.health}  Атака: {Knight.attack}')
        l2.pack()
        l3 = tkinter.Label(defenderTab,
                           text=f'Здоровье: {Defender.health}  Атака: {Defender.attack}  Защита: {Defender.defence}')
        l3.pack()
        l4 = tkinter.Label(vampireTab,
                           text=f'Здоровье: {Vampire.health}  Атака: {Vampire.attack}  Вампиризм: {Vampire.vamperism}')
        l4.pack()
        l5 = tkinter.Label(lancerTab, text=f'Здоровье: {Lancer.health}  Атака: {Lancer.attack}')
        l5.pack()

        classesnotebook.pack(fill='both', expand=True)
        winClasses.mainloop()


def Authors():
    if not createdWinAuthors.created:
        winAuthors = tkinter.Toplevel(window, background='grey70')
        winAuthors.focus_set()
        winAuthors.title('Authors of this game')
        winAuthors.geometry(
            f"{1000}x{500}+{(window.winfo_screenwidth() // 2) - (900 // 2)}+{(window.winfo_screenheight() // 2) - (700 // 2)}")

        programmer = tkinter.Label(winAuthors, text='Программисты: Полина Шестика, Данила Плеханов', background='grey70')
        artists = tkinter.Label(winAuthors, text='Художники: Кира Конопатова, Кирилл Балакшин', background='grey70')
        team_leader = tkinter.Label(winAuthors, text='Лидер команды: Владислав Игоревич', background='grey70')

        programmer.pack()
        artists.pack()
        team_leader.pack()

        winAuthors.mainloop()


def Settings():
    pass


def check_tab_exists_by_label(label):
    tabs = notebook.tabs()
    for tab in tabs:
        tab_label = notebook.tab(tab)["text"]
        if tab_label == label:
            return True
    return False


window = tkinter.Tk()
window.title('Get damage')
music_name = "48bb90af8e1e401.mp3"
mixer.init()

window.iconbitmap('images/get_DAMAGE_0.2.ico')
play = False
createdWinInfo = Created()
createdWinClasses = Created()
createdWinAuthors = Created()
createdWinSettings = Created()

window.geometry(
    f"{800}x{500}+{(window.winfo_screenwidth() // 2) - (1800 // 2)}+{(window.winfo_screenheight() // 2) - (700 // 2)}")

window.bind('<KeyPress>', keyboardDetection)

fontD = tkinter.font.nametofont('TkDefaultFont')
fontD.configure(family='Epilepsy Sans', size=30)

notebook = Notebook()
tab1 = tkinter.ttk.Frame(notebook)
notebook.add(tab1, text='Дом')

style = tkinter.ttk.Style()
style.configure('TNotebook.Tab', font=('Epilepsy Sans', 20))

img = ImageTk.PhotoImage(Image.open("images/get_damage_icon.png"))
panel = tkinter.Label(tab1, image=img)
panel.pack(side="top", fill="both")

just_a_btn = tkinter.Button(tab1, text='Песочница', command=chooseMode, font=fontD)
just_a_btn.pack(side="top")

music_crossed = ImageTk.PhotoImage(Image.open('images/music-crossed-pixil.png'))
music = ImageTk.PhotoImage(
    Image.open('images/music-pixil.png'))
btnMusic = tkinter.Button(tab1, image=music, command=playMusic)
btnMusic.pack(side='bottom', anchor='se', pady='10', padx='5')

file_menu = tkinter.Menu(window, tearoff=0)
file_menu.add_command(label='Информация', command=Info)
file_menu.add_command(label='Информация о классах', command=ClassesData)
file_menu.add_command(label='Авторы', command=Authors)
file_menu.add_command(label='Настройки', command=Settings)
window.config(menu=file_menu)

notebook.pack(fill='both', expand=True)

window.mainloop()
