class Warrior:
    health: int = 50
    attack: int = 5
    is_alive: bool

    def __init__(self):
        self.attack = 5
        self.health = 50
        self.is_alive = True

    def takingDamage(self, damage: float):
        self.health -= damage
        if self.health <= 0:
            self.is_alive = False


class Knight(Warrior):
    attack = 7
    health = Warrior.health

    def __init__(self):
        super().__init__()
        self.attack = 7


class Defender(Warrior):
    defence: int = 3
    health = 60
    attack = 3

    def __init__(self):
        super().__init__()
        self.defence = 3
        self.health = 60
        self.attack = 3

    def takingDamage(self, damage: int):
        if damage > self.defence:
            self.health -= damage - self.defence
            if self.health <= 0:
                self.is_alive = False


class Vampire(Warrior):
    vamperism: float = 0.5
    health: int = 40
    attack: int = 4

    def __init__(self):
        super().__init__()
        self.vamperism = Vampire.vamperism
        self.health = 40
        self.attack = 4


class Lancer(Warrior):
    attack = 6
    health = 50

    def __init__(self):
        super().__init__()
        self.attack = 6
        self.health = 50


class Army:
    units: list[Warrior]

    def __init__(self):
        self.units = []

    def add_units(self, numbers: int, warrior_type):
        for i in range(numbers):
            self.units.append(warrior_type())


def Battle(army1: Army, army2: Army):
    pointer1 = 0
    pointer2 = 0
    while pointer1 < len(army1.units) and pointer2 < len(army2.units):
        if pointer1 + 1 < len(army1.units) and pointer2 + 1 < len(army2.units):
            if fight(army1.units[pointer1], army2.units[pointer2], army2.units[pointer2 + 1],
                     army1.units[pointer1 + 1]):
                pointer2 += 1
            else:
                pointer1 += 1
        elif pointer1 + 1 < len(army1.units) and pointer2 + 1 == len(army2.units):
            if fight(army1.units[pointer1], army2.units[pointer2], army1.units[pointer1 + 1]):
                pointer2 += 1
            else:
                pointer1 += 1
        elif pointer1 + 1 == len(army1.units) and pointer2 + 1 < len(army2.units):
            if fight(army1.units[pointer1], army2.units[pointer2], army2.units[pointer2 + 1]):
                pointer2 += 1
            else:
                pointer1 += 1
        elif pointer1 + 1 == len(army1.units) and pointer2 + 1 == len(army2.units):
            if fight(army1.units[pointer1], army2.units[pointer2]):
                pointer2 += 1
            else:
                pointer1 += 1
    if pointer1 == len(army1.units):
        return "Победа второй армии"
    else:
        return "Победа первой армии"


def fight(fighter1: Warrior, fighter2: Warrior, fighter3: Warrior = None, fighter4: Warrior = None):
    while fighter2.is_alive and fighter1.is_alive:
        if isinstance(fighter1, Vampire):
            fighter2.takingDamage(fighter1.attack)
            if isinstance(fighter2, Defender):
                if fighter1.health < Vampire.health:
                    fighter1.health += (fighter1.attack - fighter2.defence) * fighter1.vamperism
            else:
                if fighter1.health < Vampire.health:
                    fighter1.health += fighter1.attack * fighter1.vamperism
        elif isinstance(fighter1, Lancer):
            fighter2.takingDamage(fighter1.attack)
            if fighter3 is not None:
                if fighter3.is_alive:
                    fighter3.takingDamage(fighter1.attack * 0.5)
        else:
            fighter2.takingDamage(fighter1.attack)

        if fighter2.is_alive:
            if isinstance(fighter2, Vampire):
                if isinstance(fighter1, Defender):
                    if fighter2.health < Vampire.health:
                        fighter2.health += (fighter2.attack - fighter1.defence) * fighter2.vamperism
                else:
                    if fighter2.health < Vampire.health:
                        fighter2.health += fighter2.attack * fighter2.vamperism
            elif isinstance(fighter2, Lancer):
                fighter1.takingDamage(fighter2.attack)
                if fighter4 is not None:
                    if fighter4.is_alive:
                        fighter4.takingDamage(fighter2.attack * 0.5)
            else:
                fighter1.takingDamage(fighter2.attack)

        else:
            return True
    return False
