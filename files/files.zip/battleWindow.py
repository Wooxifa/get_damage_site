import tkinter
import tkinter.font as font
import tkinter.ttk as ttk
from tkinter import messagebox

import classes


def battle_settings(check_tab_exists_by_label, notebook: ttk.Notebook, fontD: font.Font):
    if not check_tab_exists_by_label('Битва'):
        window = ttk.Frame()
        notebook.add(window, text='Битва')
        notebook.select(window)

        def keyboardDetection(event):
            if event.keysym == 'b' or event.keycode == 66:
                DoBattle()
            if event.keysym == 'e' or event.keycode == 69:
                CreatingArmy()

        window.bind('<KeyPress>', keyboardDetection)
        armyF = classes.Army()
        armyS = classes.Army()

        def CreatingArmy():
            notebook.bind('<<NotebookTabChanged>>', lambda e: fontD.configure(size=30) if notebook.tab(notebook.index(notebook.select()))['text'] == 'Создание армии' else fontD.configure(size=60))
            if not check_tab_exists_by_label('Создание армии'):
                armyCreatingFrame = ttk.Frame(notebook)
                notebook.add(armyCreatingFrame, text='Создание армии')
                notebook.select(armyCreatingFrame)
                leftFrame = ttk.Frame(armyCreatingFrame)
                rightFrame = ttk.Frame(armyCreatingFrame)
                leftFrame.pack(side=tkinter.LEFT, padx='5', pady='10')
                rightFrame.pack(side=tkinter.RIGHT, padx='5', pady='10')
                label1 = ttk.Label(leftFrame, text='Первая армия')
                warriorFrame1 = ttk.Frame(leftFrame)
                entryCountWarriors1 = tkinter.Scale(warriorFrame1, from_=0, to=20, orient=tkinter.HORIZONTAL)
                warriorLabel1 = ttk.Label(warriorFrame1, text='Воины', font=fontD)
                knightsFrame1 = ttk.Frame(leftFrame)
                entryCountKnights1 = tkinter.Scale(knightsFrame1, from_=0, to=20, orient=tkinter.HORIZONTAL)
                knightsLabel1 = ttk.Label(knightsFrame1, text='Рыцари', font=fontD)
                defendersFrame1 = ttk.Frame(leftFrame)
                entryCountDefenders1 = tkinter.Scale(defendersFrame1, from_=0, to=20, orient=tkinter.HORIZONTAL)
                defendersLabel1 = ttk.Label(defendersFrame1, text='Защитники', font=fontD)
                vampiresFrame1 = ttk.Frame(leftFrame)
                entryCountVampires1 = tkinter.Scale(vampiresFrame1, from_=0, to=20, orient=tkinter.HORIZONTAL)
                vampiresLabel = ttk.Label(vampiresFrame1, text='Вампиры', font=fontD)
                lancersFrame1 = ttk.Frame(leftFrame)
                entryCountLancers1 = tkinter.Scale(lancersFrame1, from_=0, to=20, orient=tkinter.HORIZONTAL)
                lancersLabel1 = ttk.Label(lancersFrame1, text='Копейщики', font=fontD)

                label1.pack(pady='10', padx='5')
                warriorFrame1.pack()
                warriorLabel1.pack(side='left')
                entryCountWarriors1.pack(pady='10', padx='5')

                knightsFrame1.pack()
                knightsLabel1.pack(side='left')
                entryCountKnights1.pack(pady='10', padx='5')

                defendersFrame1.pack()
                defendersLabel1.pack(side='left')
                entryCountDefenders1.pack(pady='10', padx='5')

                vampiresFrame1.pack()
                vampiresLabel.pack(side='left')
                entryCountVampires1.pack(pady='10', padx='5')

                lancersFrame1.pack()
                lancersLabel1.pack(side='left')
                entryCountLancers1.pack(pady='10', padx='5')

                label2 = ttk.Label(rightFrame, text='Вторая армия', font=fontD)
                warriorFrame2 = ttk.Frame(rightFrame)
                entryCountWarriors2 = tkinter.Scale(warriorFrame2, from_=0, to=20, orient=tkinter.HORIZONTAL)
                warriorLabel2 = ttk.Label(warriorFrame2, text='Воины', font=fontD)
                knightsFrame2 = ttk.Frame(rightFrame)
                entryCountKnights2 = tkinter.Scale(knightsFrame2, from_=0, to=20, orient=tkinter.HORIZONTAL)
                knightsLabel2 = ttk.Label(knightsFrame2, text='Рыцари', font=fontD)
                defendersFrame2 = ttk.Frame(rightFrame)
                entryCountDefenders2 = tkinter.Scale(defendersFrame2, from_=0, to=20, orient=tkinter.HORIZONTAL)
                defendersLabel2 = ttk.Label(defendersFrame2, text='Защитники', font=fontD)
                vampiresFrame2 = ttk.Frame(rightFrame)
                entryCountVampires2 = tkinter.Scale(vampiresFrame2, from_=0, to=20, orient=tkinter.HORIZONTAL)
                vampiresLabel2 = ttk.Label(vampiresFrame2, text='Вампиры', font=fontD)
                lancersFrame2 = ttk.Frame(rightFrame)
                entryCountLancers2 = tkinter.Scale(lancersFrame2, from_=0, to=20, orient=tkinter.HORIZONTAL)
                lancersLabel2 = ttk.Label(lancersFrame2, text='Копейщики', font=fontD)

                label2.pack(pady='10', padx='5')
                warriorFrame2.pack()
                warriorLabel2.pack(side='right')
                entryCountWarriors2.pack(pady='10', padx='5')

                knightsFrame2.pack()
                knightsLabel2.pack(side='right')
                entryCountKnights2.pack(pady='10', padx='5')

                defendersFrame2.pack()
                defendersLabel2.pack(side='right')
                entryCountDefenders2.pack(pady='10', padx='5')

                vampiresFrame2.pack()
                vampiresLabel2.pack(side='right')
                entryCountVampires2.pack(pady='10', padx='5')

                lancersFrame2.pack()
                lancersLabel2.pack(side='right')
                entryCountLancers2.pack(pady='10', padx='5')

                def keyboardArm(event):
                    if event.keycode == 69:
                        CreateArmy()
                    if event.keycode == 27:
                        armyCreatingFrame.destroy()

                def CreateArmy():
                    armyF.units = []
                    armyS.units = []

                    armyF.add_units(int(entryCountWarriors1.get()), classes.Warrior)
                    armyF.add_units(int(entryCountKnights1.get()), classes.Knight)
                    armyF.add_units(int(entryCountDefenders1.get()), classes.Defender)
                    armyF.add_units(int(entryCountVampires1.get()), classes.Vampire)
                    armyF.add_units(int(entryCountLancers1.get()), classes.Lancer)

                    armyS.add_units(int(entryCountWarriors2.get()), classes.Warrior)
                    armyS.add_units(int(entryCountKnights2.get()), classes.Knight)
                    armyS.add_units(int(entryCountDefenders2.get()), classes.Defender)
                    armyS.add_units(int(entryCountVampires2.get()), classes.Vampire)
                    armyS.add_units(int(entryCountLancers2.get()), classes.Lancer)

                    armyF.units = armyF.units[:60]
                    armyS.units = armyF.units[:60]

                    match ((len(armyF.units) > 0), (len(armyS.units) > 0)):
                        case (False, False):
                            messagebox.showerror('Недостаточно бойцов', 'Добавьте хотя бы одного бойца к каждой армии')
                        case (True, False):
                            messagebox.showerror('Недостаточно бойцов', 'Добавьте хотя бы одного бойца к второй армии')
                        case (False, True):
                            messagebox.showerror('Недостаточно бойцов', 'Добавьте хотя бы одного бойца к первой армии')
                        case (True, True):
                            armyCreatingFrame.destroy()
                            fontD.config(size=60)

                btnArm2 = tkinter.Button(armyCreatingFrame, text="Подтвердить", cursor='hand2', command=CreateArmy)
                btnArm2.pack(pady='10', padx='5', side=tkinter.BOTTOM)
                armyCreatingFrame.bind('<KeyPress>', keyboardArm)

        def DoBattle():
            if len(armyF.units) > 0 and len(armyS.units) > 0:
                winStatus = ttk.Label(window, text=(classes.Battle(armyF, armyS)), font=fontD)
                winStatus.pack(pady='10', padx='5')
                armyF.units, armyS.units = [], []
            else:
                match ((len(armyF.units) > 0), (len(armyS.units) > 0)):
                    case (False, False):
                        messagebox.showerror('Недостаточно бойцов', 'Добавьте хотя бы одного бойца к каждой армии')
                    case (True, False):
                        messagebox.showerror('Недостаточно бойцов', 'Добавьте хотя бы одного бойца к второй армии')
                    case (False, True):
                        messagebox.showerror('Недостаточно бойцов', 'Добавьте хотя бы одного бойца к первой армии')

        btnArm = tkinter.Button(window, text="Создать армии", cursor='hand2', command=CreatingArmy)
        btnBattle = tkinter.Button(window, text="Битва", cursor='hand2', command=DoBattle)
        btnArm.pack(pady='10', padx='5')
        btnBattle.pack(pady='10', padx='5')
